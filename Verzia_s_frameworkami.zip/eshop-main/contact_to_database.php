<?php
// Database connection parameters
$servername = "localhost"; // Database server name (usually localhost)
$username = ""; // Database username (leave empty if no username is required)
$password = ""; // Database password (leave empty if no password is set)
$dbname = "database"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape user inputs for security
    $meno = mysqli_real_escape_string($conn, $_POST['meno']);
    $predmet = mysqli_real_escape_string($conn, $_POST['predmet']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $mobil = mysqli_real_escape_string($conn, $_POST['mobil']);
    $sprava = mysqli_real_escape_string($conn, $_POST['sprava']);

    // Insert data into database
    $sql = "INSERT INTO contact_form (meno, predmet, email, mobil, sprava)
    VALUES ('$meno', '$predmet', '$email', '$mobil', '$sprava')";

    if ($conn->query($sql) === TRUE) {
        echo "Records inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>
