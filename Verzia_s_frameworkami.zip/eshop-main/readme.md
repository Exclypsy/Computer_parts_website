# Eshop

## Database

### Creating database
 - remove cache by deleting content of directory `/temp`
 - run console command `php ./bin/console o:s:u --force --complete`