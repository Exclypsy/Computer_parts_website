<?php

namespace App;

class Paginator extends \Nette\Utils\Paginator
{
    public function __construct(
        int $page,
        int $totalCount
    ) {
        $this->page = $page;
        $this->itemCount = $totalCount;
    }
}