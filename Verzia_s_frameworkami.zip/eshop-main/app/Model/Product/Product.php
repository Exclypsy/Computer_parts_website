<?php

namespace App\Model\Product;

use App\Model\Tax\Tax;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'product')]
class Product
{
    #[ORM\Id, ORM\Column, ORM\GeneratedValue]
    private int $id;

    #[ORM\Column(type: 'string')]
    private string $name;

    #[ORM\Column(type: 'text')]
    private string $description;

    #[ORM\Column(type: 'float')]
    private float $price;

    #[ORM\ManyToOne(targetEntity: Tax::class)]
    #[ORM\JoinColumn(nullable: false)]
    private Tax $tax;

    #[ORM\Column(type: 'datetime_immutable')]
    private \DateTimeInterface $createdAt;

    public function __construct(ProductData $data)
    {
        $this->createdAt = new \DateTimeImmutable('now');
        $this->edit($data);
    }

    public function edit(ProductData $data): void
    {
        $this->name = $data->name;
        $this->description = $data->description;
        $this->price = $data->price;
        $this->tax = $data->tax;
    }

    public function getData(): ProductData
    {
        $data = new ProductData();
        $data->name = $this->name;
        $data->description = $this->description;
        $data->price = $this->price;
        $data->tax = $this->tax;

        return $data;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function getPrice(): float
    {
        return $this->price;
    }

    public function getTax(): Tax
    {
        return $this->tax;
    }

    public function getCreatedAt(): \DateTimeInterface
    {
        return $this->createdAt;
    }
}