<?php

namespace App\Model\Product;

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class ProductRepository
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    ) {

    }

    public function find(int $id): ?Product
    {
        return $this->getRepository()->find($id);
    }

    public function countAll(): int
    {
        return (int) $this->getRepository()
            ->createQueryBuilder('e')
            ->select('count(e.id) AS total')
            ->getQuery()
            ->getSingleScalarResult();
    }

    public function findAll(int $offset = 0, int $limit = 25): array
    {
        return $this->getRepository()
            ->createQueryBuilder('e')
            ->orderBy('e.id', 'DESC')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }

    /**
     * @return EntityRepository<Product>
     */
    private function getRepository(): EntityRepository
    {
        return $this->entityManager->getRepository(Product::class);
    }
}