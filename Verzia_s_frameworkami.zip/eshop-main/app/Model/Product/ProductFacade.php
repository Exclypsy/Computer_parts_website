<?php

namespace App\Model\Product;

use App\Model\Tax\Tax;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Mapping as ORM;

class ProductFacade
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly ProductRepository $productRepository,
    ) {

    }

    public function remove(int|Product $productOrId): void
    {
        $product = $productOrId instanceof Product ? $productOrId : $this->productRepository->find($productOrId);
        $this->entityManager->remove($product);
        $this->entityManager->flush();
    }

    public function create(ProductData $data): Product
    {
        $entity = new Product($data);
        $this->entityManager->persist($entity);
        $this->entityManager->flush();

        return $entity;
    }
}