<?php

namespace App\Model\Product;

use App\Model\Tax\Tax;
use Doctrine\ORM\Mapping as ORM;

class ProductData
{
    public string $name;
    public string $description;
    public float $price;
    public Tax $tax;
}