<?php

namespace App\Model\Product;

use App\Model\Tax\Tax;
use App\Model\Tax\TaxRepository;
use Doctrine\ORM\Mapping as ORM;

class ProductDataFactory
{
    public function __construct(
        private readonly TaxRepository $taxRepository,
    )
    {
    }

    public function createFromFormData(array $formData, Product $product = null): ProductData
    {
        $data = $product ? $product->getData() : new ProductData();
        $data->name = $formData['name'];
        $data->description = $formData['description'];
        $data->price = round((float) $formData['price'], 2);
        $data->tax = $this->taxRepository->find($formData['tax']);

        return $data;
    }
}