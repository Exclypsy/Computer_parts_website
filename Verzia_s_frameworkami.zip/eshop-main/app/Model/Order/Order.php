<?php

namespace App\Model\Order;

use App\Model\Contact\Contact;
use App\Model\Order\Product\OrderProduct;
use App\Model\PaymentMethod\PaymentMethod;
use App\Model\ShippingMethod\ShippingMethod;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'orders')]
class Order
{
    #[ORM\Id, ORM\Column, ORM\GeneratedValue]
    private int $id;

    #[ORM\ManyToOne(targetEntity: Contact::class)]
    #[ORM\JoinColumn(nullable: false)]
    private Contact $deliveryContact;

    /** @var Collection<OrderProduct> */
    #[ORM\OneToMany(mappedBy: 'order', targetEntity: OrderProduct::class, cascade: ['remove', 'persist'])]
    private Collection $orderProducts;

    #[ORM\Column(type: 'datetime_immutable')]
    private \DateTimeInterface $createdAt;

//    #[ORM\ManyToOne(targetEntity: PaymentMethod::class)]
//    #[ORM\JoinColumn(onDelete: 'SET NULL')]
//    private PaymentMethod $paymentMethod;
//
//    #[ORM\Column(type: 'float')]
//    private float $paymentPrice;
//
//    #[ORM\Column(type: 'float')]
//    private float $paymentTax;
//
//    #[ORM\ManyToOne(targetEntity: ShippingMethod::class)]
//    #[ORM\JoinColumn(onDelete: 'SET NULL')]
//    private ShippingMethod $shippingMethod;
//
//    #[ORM\Column(type: 'float')]
//    private float $shippingPrice;
//
//    #[ORM\Column(type: 'float')]
//    private float $shippingTax;

    public function __construct()
    {
        $this->orderProducts = new ArrayCollection();
        $this->createdAt = new \DateTimeImmutable('now');
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getDeliveryContact(): Contact
    {
        return $this->deliveryContact;
    }

    /**
     * @return OrderProduct[]
     */
    public function getOrderProducts(): array
    {
        return $this->orderProducts->toArray();
    }

    public function getCreatedAt(): \DateTimeInterface
    {
        return $this->createdAt;
    }

    public function getTotalPrice(): float
    {
        $price = 0;
        foreach ($this->orderProducts as $product) {
            $price =  $price + $product->getTotalPrice();
        }
        return $price;
    }
}