<?php

namespace App\Model\Tax;

use App\Model\Product\Product;
use App\Model\Tax\Tax;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Mapping as ORM;

class TaxRepository
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    ) {

    }

    public function find(int $id): ?Tax
    {
        return $this->getRepository()->find($id);
    }

    public function mapForFormData(): array
    {
        $qb = $this->getRepository()
            ->createQueryBuilder('e')
            ->orderBy('e.value');

        $items = [];
        /** @var Tax $item */
        foreach ($qb->getQuery()->getResult() as $item) {
            $items[$item->getId()] = $item->getValue().'%';
        }

        return $items;
    }

    /**
     * @return EntityRepository<Tax>
     */
    private function getRepository(): EntityRepository
    {
        return $this->entityManager->getRepository(Tax::class);
    }
}