<?php

namespace App\Model\Cart;

class CartData
{

}