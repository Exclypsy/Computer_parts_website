<?php

namespace App\Model\Cart;

use App\Model\Cart\Product\CartProduct;
use App\Model\Product\Product;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'cart')]
class Cart
{
    #[ORM\Id, ORM\Column, ORM\GeneratedValue]
    private int $id;

    /** @var Collection<CartProduct> */
    #[ORM\OneToMany(mappedBy: 'cart', targetEntity: CartProduct::class, cascade: ['remove', 'persist'])]
    private Collection $cartProducts;

    public function __construct(CartData $data)
    {
        $this->cartProducts = new ArrayCollection();
        $this->edit($data);
    }

    public function edit(CartData $data): void
    {

    }

    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return CartProduct[]
     */
    public function getCartProducts(): array
    {
        return $this->cartProducts->toArray();
    }

    public function getByProduct(Product $product): ?CartProduct
    {
        foreach ($this->cartProducts as $cartProduct) {
            if($product->getId() == $cartProduct->getProduct()->getId()) {
                return $cartProduct;
            }
        }

        return null;
    }

    public function getTotalPrice(): float
    {
        $price = 0;
        foreach ($this->cartProducts as $cartProduct) {
            $price =  $price + $cartProduct->getTotalPrice();
        }
        return $price;
    }

    public function getProductCount(): int
    {
        $amount = 0;
        foreach ($this->cartProducts as $cartProduct) {
            $amount = $amount + $cartProduct->getAmount();
        }

        return $amount;
    }
}