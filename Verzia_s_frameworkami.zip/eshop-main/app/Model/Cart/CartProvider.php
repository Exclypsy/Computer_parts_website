<?php

namespace App\Model\Cart;

use Nette\Http\Session;
use Nette\Http\SessionSection;

class CartProvider
{
    const SESSION_KEY = 'customer-cart';

    public function __construct(
        private readonly Session $session,
        private readonly CartRepository $cartRepository,
        private readonly CartFacade $cartFacade,
    )
    {
    }

    public function provide(): Cart
    {
        $id = $this->getSession()->get('id');
        if($id) {
            $cart = $this->cartRepository->find((int) $id);
        }

        $cart = $cart ?? $this->cartFacade->createBlank();

        $this->getSession()->set('id', $cart->getId());

        return  $cart;
    }

    private function getSession(): SessionSection
    {
        return $this->session->getSection(self::SESSION_KEY);
    }
}