<?php

namespace App\Model\Cart\Product;

use App\Model\Cart\Cart;
use App\Model\Product\Product;

class CartProductData
{
    public Product $product;
    public Cart $cart;
    public int $amount;
}