<?php

namespace App\Model\Cart\Product;

use App\Model\Cart\Cart;
use App\Model\Cart\CartData;
use App\Model\Product\Product;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'cart_product')]
class CartProduct
{
    #[ORM\Id, ORM\Column, ORM\GeneratedValue]
    private int $id;

    #[ORM\ManyToOne(targetEntity: Cart::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Cart $cart;

    #[ORM\ManyToOne(targetEntity: Product::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Product $product;

    #[ORM\Column(type: 'integer')]
    private int $amount;

    public function __construct(CartProductData $data)
    {
        $this->cart = $data->cart;
        $this->product = $data->product;
        $this->edit($data);
    }

    public function edit(CartProductData $data): void
    {
        $this->amount = $data->amount;
    }

    public function getData(): CartProductData
    {
        $data = new CartProductData();
        $data->cart = $this->cart;
        $data->product = $this->product;
        $data->amount = $this->amount;

        return $data;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getProduct(): Product
    {
        return $this->product;
    }

    public function getAmount(): int
    {
        return $this->amount;
    }

    public function getTotalPrice(): float
    {
        return $this->product->getPrice() * $this->amount;
    }
}