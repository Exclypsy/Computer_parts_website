<?php

namespace App\Model\Cart\Product;

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class CartProductRepository
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    ) {

    }

    public function find(int $id): ?CartProduct
    {
        return $this->getRepository()->find($id);
    }

    /**
     * @return EntityRepository<CartProduct>
     */
    private function getRepository(): EntityRepository
    {
        return $this->entityManager->getRepository(CartProduct::class);
    }
}