<?php

namespace App\Model\Cart\Product;

use Doctrine\ORM\EntityManagerInterface;

class CartProductFacade
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly CartProductRepository $cartProductRepository,
    ) {

    }

    public function remove(int|CartProduct $productOrId): void
    {
        $product = $productOrId instanceof CartProduct ? $productOrId : $this->cartProductRepository->find($productOrId);
        $this->entityManager->remove($product);
        $this->entityManager->flush();
    }

    public function edit(CartProduct $cartProduct, CartProductData $data): void
    {
        $cartProduct->edit($data);
        $this->entityManager->persist($cartProduct);
        $this->entityManager->flush();
    }

    public function create(CartProductData $data): CartProduct
    {
        $entity = new CartProduct($data);
        $this->entityManager->persist($entity);
        $this->entityManager->flush();

        return $entity;
    }
}