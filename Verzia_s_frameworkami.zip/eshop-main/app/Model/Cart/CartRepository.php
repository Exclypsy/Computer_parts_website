<?php

namespace App\Model\Cart;

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class CartRepository
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    ) {

    }

    public function find(int $id): ?Cart
    {
        return $this->getRepository()->find($id);
    }

    /**
     * @return EntityRepository<Cart>
     */
    private function getRepository(): EntityRepository
    {
        return $this->entityManager->getRepository(Cart::class);
    }
}