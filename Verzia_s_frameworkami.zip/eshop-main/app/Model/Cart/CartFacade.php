<?php

namespace App\Model\Cart;

use App\Model\Product\Product;
use Doctrine\ORM\EntityManagerInterface;

class CartFacade
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly CartRepository         $cartRepository,
    ) {

    }

    public function remove(int|Cart $cartOrId): void
    {
        $product = $cartOrId instanceof Cart ? $cartOrId : $this->cartRepository->find($cartOrId);
        $this->entityManager->remove($product);
        $this->entityManager->flush();
    }

    public function create(CartData $data): Cart
    {
        $entity = new Cart($data);
        $this->entityManager->persist($entity);
        $this->entityManager->flush();

        return $entity;
    }

    public function createBlank(): Cart
    {
        $data=  new CartData();
        return $this->create($data);
    }
}