<?php

namespace App\Model\PaymentMethod;

use App\Model\Tax\Tax;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'payment_method')]
class PaymentMethod
{
    #[ORM\Id, ORM\Column, ORM\GeneratedValue]
    private int $id;

    #[ORM\Column(type: 'float')]
    private float $price;

    #[ORM\ManyToOne(targetEntity: Tax::class)]
    #[ORM\JoinColumn(nullable: false)]
    private Tax $tax;
}