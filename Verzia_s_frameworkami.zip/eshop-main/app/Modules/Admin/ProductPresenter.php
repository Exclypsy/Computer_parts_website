<?php

declare(strict_types=1);

namespace App\Modules\Admin;

use App\Model\Product\Product;
use App\Model\Product\ProductDataFactory;
use App\Model\Product\ProductFacade;
use App\Model\Product\ProductRepository;
use App\Modules\Admin\Auth\Form\ProductFormFactory;
use App\Modules\Admin\Product\Grid\ProductGridFactory;
use Nette\Application\UI\Form;
use Ublaboo\DataGrid\DataGrid;

final class ProductPresenter extends BaseAdminPresenter
{
    public function __construct(
        private readonly ProductGridFactory $productGridFactory,
        private readonly ProductFormFactory $productFormFactory,
        private readonly ProductDataFactory $productDataFactory,
        private readonly ProductFacade $productFacade,
        private readonly ProductRepository $productRepository,
    ) {
    }

    public function actionDefault()
    {

    }

    public function actionAdd()
    {

    }

    public function handleRemove(int $id): void
    {
        $this->productFacade->remove($this->getProduct($id));
        $this['productGrid']->redrawControl();
        $this->flashMessage('Product was removed', 'success');
        $this->redrawControl('flashes');
    }

    public function createComponentCreateProductForm(): Form
    {
        $form = $this->productFormFactory->create();

        $form->onError[] = function() use ($form) {
            $form->addError('Fix form errors');
        };

        $form->onSuccess[] = function(Form $form, array $formValues) {
            $product = $this->productFacade->create($this->productDataFactory->createFromFormData($formValues));
            $this->flashMessage('Product was created', 'success');
            $this->redirect(':Admin:Product:default');
//            $this->redirect(':Admin:Product:edit', ['id' => $product->getId()]);
        };

        return $form;
    }

    public function createComponentProductGrid(): DataGrid
    {
        return $this->productGridFactory->create();
    }

    private function getProduct($id): Product
    {
        $product = $this->productRepository->find($id);
        if(!$product) {
            $this->flashMessage('Product was not found');
            $this->redirect(':Admin:Product:default');
        }

        return $product;
    }
}
