<?php

namespace App\Modules\Admin\Auth\Form;

use Nette\Application\UI\Form;

class LoginFormFactory
{
    public function create(): Form
    {
        $form = new Form();
        $form->addProtection();

        $form->addText('login', 'Login')
            ->setRequired();

        $form->addPassword('password', 'Password')
            ->setRequired();

        $form->addSubmit('send', 'Login');

        return $form;
    }
}