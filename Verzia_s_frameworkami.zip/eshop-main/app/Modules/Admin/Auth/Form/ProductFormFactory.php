<?php

namespace App\Modules\Admin\Auth\Form;

use App\Model\Tax\TaxRepository;
use Nette\Application\UI\Form;

class ProductFormFactory
{
    public function __construct(
        private readonly TaxRepository $taxRepository,
    )
    {
    }

    public function create(): Form
    {
        $form = new Form();
        $form->addProtection();

        $form->addText('name', 'Name')
            ->setRequired()
            ->addRule(Form::MaxLength, null, 255);

        $form->addTextArea('description', 'Desription')
            ->setRequired();

        $form->addFloat('price', 'Price')
            ->setRequired()
            ->setOption('description', 'Price with VAT')
            ->addRule(Form::Min, null, 0);

        $form->addSelect('tax', 'Tax')
            ->setPrompt('')
            ->setItems($this->taxRepository->mapForFormData())
            ->setRequired();

        $form->addSubmit('send', 'Login');

        return $form;
    }
}