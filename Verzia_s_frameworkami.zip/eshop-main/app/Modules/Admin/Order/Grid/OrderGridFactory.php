<?php

namespace App\Modules\Admin\Order\Grid;

use App\Model\Order\Order;
use App\Model\Product\Product;
use Doctrine\ORM\EntityManagerInterface;
use Ublaboo\DataGrid\DataGrid;

class OrderGridFactory
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    )
    {
    }

    public function create(): DataGrid
    {
        $qb = $this->entityManager
            ->getRepository(Order::class)
            ->createQueryBuilder('e');

        $grid = new DataGrid();
        $grid->setDataSource($qb);

        $grid->defaultSort = ['createdAt' => 'DESC'];

        $grid->addColumnText('name', 'Name')
            ->setRenderer(function(Order $order) {
                return sprintf('%s %s', $order->getDeliveryContact()->getFirstname(), $order->getDeliveryContact()->getLastname());
            });

        $grid->addColumnText('price', 'Price')
            ->setRenderer(function(Order $order) {
                return sprintf('%s EUR', number_format($order->getTotalPrice(), 2, ',', ' '));
            });

        $grid->addColumnDateTime('createdAt', 'Created at')
            ->setSortable();

        $grid->addAction('action', 'Edit', 'edit');

        return $grid;
    }
}