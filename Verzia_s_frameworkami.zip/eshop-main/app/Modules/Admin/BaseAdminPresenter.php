<?php

declare(strict_types=1);

namespace App\Modules\Admin;

use Nette\Application\UI\Presenter;

abstract class BaseAdminPresenter extends Presenter
{
    public function startup()
    {
        parent::startup();
        $this->setLayout(__DIR__.'/templates/@layout.latte');

        $this->checkLogin();
    }

    private function checkLogin()
    {
        if ($this->getPresenter()->getName() != 'Admin:Auth' && !$this->getUser()->isLoggedIn()) {
            $this->redirect(':Admin:Auth:login');
        }
    }
}
