<?php

namespace App\Modules\Admin\Product\Grid;

use App\Model\Product\Product;
use Doctrine\ORM\EntityManagerInterface;
use Ublaboo\DataGrid\DataGrid;

class ProductGridFactory
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    )
    {
    }

    public function create(): DataGrid
    {
        $qb = $this->entityManager
            ->getRepository(Product::class)
            ->createQueryBuilder('e');

        $grid = new DataGrid();
        $grid->setDataSource($qb);

        $grid->addColumnText('name', 'Name')
            ->setFilterText('name');

        $grid->addColumnText('price', 'Price')
            ->setRenderer(function(Product $product) {
                return sprintf('%s EUR', number_format($product->getPrice(), 2, ',', ' '));
            })
            ->setSortable()
            ->setFilterText('price');

        $grid->addAction('remove', 'Remove', 'remove!')
            ->setClass('btn btn-secondary btn-sm ajax');

        return $grid;
    }
}