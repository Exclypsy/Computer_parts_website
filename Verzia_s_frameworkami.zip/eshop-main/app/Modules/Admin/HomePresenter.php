<?php

declare(strict_types=1);

namespace App\Modules\Admin;

final class HomePresenter extends BaseAdminPresenter
{
    public function __construct(

    ) {
    }

    public function actionDefault()
    {

    }
}
