<?php

declare(strict_types=1);

namespace App\Modules\Admin;

use App\Model\Order\Order;
use App\Modules\Admin\Order\Grid\OrderGridFactory;
use Doctrine\ORM\EntityManagerInterface;
use Ublaboo\DataGrid\DataGrid;

final class OrderPresenter extends BaseAdminPresenter
{
    public function __construct(
        private readonly OrderGridFactory $orderGridFactory,
        private readonly EntityManagerInterface $entityManager,
    ) {
    }

    public function actionDefault()
    {

    }

    public function actionEdit(string $id)
    {
        $order = $this->entityManager->getRepository(Order::class)->find($id);
        if(!$order) {
            $this->flashMessage('Order was not found');
            $this->redirect(':Admin:Order:default');
        }

        $this->template->order = $order;
    }

    public function createComponentOrdersGrid(): DataGrid
    {
        return $this->orderGridFactory->create();
    }
}
