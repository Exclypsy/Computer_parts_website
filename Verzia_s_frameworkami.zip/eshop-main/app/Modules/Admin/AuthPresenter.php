<?php

declare(strict_types=1);

namespace App\Modules\Admin;

use App\Modules\Admin\Auth\Form\LoginFormFactory;
use Nette\Application\UI\Form;
use Nette\Security\AuthenticationException;

final class AuthPresenter extends BaseAdminPresenter
{
    public function __construct(
        private readonly LoginFormFactory $loginFormFactory,
    ) {
    }

    public function startup()
    {
        parent::startup();
        $this->setLayout(__DIR__.'/templates/@login-layout.latte');
    }

    public function actionLogout()
    {
        $this->user->logout(true);
        $this->redirect(':Admin:Auth:login');
    }

    public function actionLogin()
    {

    }

    public function createComponentLoginForm(): Form
    {
        $form = $this->loginFormFactory->create();

        $form->onSuccess[] = function(Form $form, array $formValues) {
            try {
                $this->user->login(
                    $formValues['login'],
                    $formValues['password'],
                );

                $this->redirect(':Admin:Home:default');
            } catch (AuthenticationException) {
                $this->flashMessage('Wrong credentials.', 'danger');
                $form->addError('Wrong credentials.');
            }
        };

        return $form;
    }
}
