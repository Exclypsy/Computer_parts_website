<?php

declare(strict_types=1);

namespace App\Modules\Front;

use App\Model\Cart\Cart;
use Latte\Runtime\Template;


class BasePresenterTemplate extends Template
{
    public Cart $cart;
}
