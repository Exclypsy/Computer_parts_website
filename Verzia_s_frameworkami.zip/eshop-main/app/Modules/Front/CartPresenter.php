<?php

declare(strict_types=1);

namespace App\Modules\Front;

use App\Model\Cart\CartFacade;
use App\Modules\Front\Cart\Form\CheckoutFormFactory;
use Doctrine\DBAL\Connection;
use Nette\Forms\Form;

final class CartPresenter extends BasePresenter
{
    public function __construct(
        private readonly CheckoutFormFactory $checkoutFormFactory,
        private readonly Connection $connection,
        private readonly CartFacade $cartFacade,
    )
    {
    }

    public function createComponentCheckoutForm(): Form
    {
        $form = $this->checkoutFormFactory->create();

        $form->onSubmit[] = function() {
            $this->redrawControl('flashes');
            $this->redrawControl('cartCheckoutSnippet');
        };

        $form->onError[] = function(Form $form) {
            $this->flashMessage('Fix form error', 'danger');
        };

        $form->onSuccess[] = function(Form $form, array $formData) {
            try {
                $this->connection->beginTransaction();

                $this->connection->insert('contact', [
                    'firstname' => $formData['firstname'],
                    'lastname' => $formData['lastname'],
                    'street' => $formData['street'],
                    'city' => $formData['city'],
                    'zip' => $formData['psc'],
                    'country' => $formData['country'],
                    'telephone' => $formData['phone'],
                    'email' => $formData['email'],
                ]);

                $contactId = $this->connection->lastInsertId();

                $this->connection->insert('orders', [
                    'delivery_contact_id' => $contactId,
                    'created_at' => (new \DateTime())->format('Y-m-d H:i:s'),
                ]);

                $orderId = $this->connection->lastInsertId();

                foreach ($this->cartProvider->provide()->getCartProducts() as $cartProduct) {
                    $this->connection->insert('order_product', [
                        'order_id' => $orderId,
                        'product_id' => $cartProduct->getProduct()->getId(),
                        'name' => $cartProduct->getProduct()->getName(),
                        'price' => $cartProduct->getProduct()->getPrice(),
                        'tax' => $cartProduct->getProduct()->getTax()->getId(),
                        'amount' => $cartProduct->getAmount(),
                    ]);
                }

                $this->cartFacade->remove($this->cartProvider->provide());

                $this->connection->commit();
                $this->flashMessage('Order was created', 'success');
            } catch (\Exception $e) {
                $this->connection->rollBack();
                $this->flashMessage('Error', 'danger');
            }

            $this->redirect(':Front:Home:default');
        };

        return $form;
    }
}
