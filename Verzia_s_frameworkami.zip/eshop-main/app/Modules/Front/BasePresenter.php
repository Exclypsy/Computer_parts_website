<?php

declare(strict_types=1);

namespace App\Modules\Front;

use App\Model\Cart\CartProvider;
use Nette\Application\UI\Presenter;
use Nette\DI\Attributes\Inject;

/**
 * @property BasePresenterTemplate $template
 */
abstract class BasePresenter extends Presenter
{
    #[Inject]
    public CartProvider $cartProvider;

    protected function startup()
    {
        $this->template->cart = $this->cartProvider->provide();

        parent::startup();
    }
}
