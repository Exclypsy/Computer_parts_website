<?php

declare(strict_types=1);

namespace App\Modules\Front;

use App\Model\Product\Product;
use Latte\Runtime\Template;


class ProductPresenterTemplate extends BasePresenterTemplate
{
    public Product $product;
}
