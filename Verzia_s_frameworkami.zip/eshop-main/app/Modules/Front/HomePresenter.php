<?php

declare(strict_types=1);

namespace App\Modules\Front;

use App\Model\Product\ProductRepository;
use App\Paginator;
use Nette\Application\UI\Presenter;

/**
 * @property HomePresenterTemplate $template
 */
final class HomePresenter extends BasePresenter
{
    private const PRODUCT_PER_PAGE = 8;

    public function __construct(
        private readonly ProductRepository $productRepository,
    ) {
    }

    public function actionDefault(int $page = 1)
    {
        $offset = abs(($page * self::PRODUCT_PER_PAGE) - self::PRODUCT_PER_PAGE);
        $this->template->products = $this->productRepository->findAll($offset, self::PRODUCT_PER_PAGE);
        $this->template->productPaginator = new Paginator($page, $this->productRepository->countAll());
    }
}
