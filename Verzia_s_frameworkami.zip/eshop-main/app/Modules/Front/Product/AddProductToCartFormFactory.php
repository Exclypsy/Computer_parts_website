<?php

namespace App\Modules\Front\Product;

use Nette\Application\UI\Form;

class AddProductToCartFormFactory
{
    public function create(): Form
    {
        $form = new Form();
        $form->addProtection();

        $form->addInteger('quantity', 'Quantity')
            ->setRequired()
            ->setDefaultValue(1)
            ->addRule(Form::Min, null, 1);

        $form->addSubmit('send', 'Add to cart');

        return $form;
    }
}