<?php

declare(strict_types=1);

namespace App\Modules\Front;

use App\Model\Cart\CartProvider;
use App\Model\Cart\Product\CartProductData;
use App\Model\Cart\Product\CartProductFacade;
use App\Model\Product\ProductRepository;
use App\Modules\Front\Product\AddProductToCartFormFactory;
use Nette\Application\BadRequestException;
use Nette\Forms\Form;

/**
 * @property ProductPresenterTemplate $template
 */
final class ProductPresenter extends BasePresenter
{
    public function __construct(
        private readonly ProductRepository           $productRepository,
        private readonly AddProductToCartFormFactory $addProductToCartFormFactory,
        private readonly CartProvider                $cartService,
        private readonly CartProductFacade $cartProductFacade,
    ) {
    }

    public function actionDetail(int $id): void
    {
        $product = $this->productRepository->find($id);

        if(!$product) {
            throw new BadRequestException();
        }

        $this->template->product = $product;
    }

    public function createComponentAddProductToCart(): Form
    {
        $form = $this->addProductToCartFormFactory->create();

        $form->onSubmit[] = function() {
            $this->redrawControl('flashes');
            $this->redrawControl('addProductToCartSnippet');
        };

        $form->onError[] = function() {
            $this->flashMessage('Fix form error', 'danger');
        };

        $form->onSuccess[] = function(Form $form,  array $formData) {
            $product = $this->productRepository->find((int) $this->getParameter('id'));
            $cart = $this->cartService->provide();
            $cartProduct = $cart->getByProduct($product);
            if($cartProduct) {
                $data = $cartProduct->getData();
                $data->amount = $data->amount + abs((int) $formData['quantity']);
                $this->cartProductFacade->edit($cartProduct, $data);
            } else {
                $data = new CartProductData();
                $data->cart = $cart;
                $data->product = $product;
                $data->amount = abs((int) $formData['quantity']);
                $this->cartProductFacade->create($data);
            }

            $form->reset();

            $this->redrawControl('headerCartSnippet');
            $this->flashMessage('Product was added to basket', 'info');
        };

        return $form;
    }
}
