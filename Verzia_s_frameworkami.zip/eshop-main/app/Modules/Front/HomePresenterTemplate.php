<?php

declare(strict_types=1);

namespace App\Modules\Front;

use App\Model\Product\Product;
use App\Paginator;
use Latte\Runtime\Template;


class HomePresenterTemplate extends Template
{
    /** @var Product[] */
    public array $products = [];
    public Paginator $productPaginator;
}
