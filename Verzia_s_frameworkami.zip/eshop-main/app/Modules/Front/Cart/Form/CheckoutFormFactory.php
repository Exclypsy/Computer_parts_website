<?php

namespace App\Modules\Front\Cart\Form;

use Nette\Application\UI\Form;

class CheckoutFormFactory
{
    public function create(): Form
    {
        $form = new Form();
        $form->addProtection();

        $form->addText('firstname', 'Firstname')
            ->setRequired()
            ->addRule(Form::MaxLength, null, 150);

        $form->addText('lastname', 'Lastname')
            ->setRequired()
            ->addRule(Form::MaxLength, null, 150);

        $form->addEmail('email', 'Email')
            ->setRequired()
            ->addRule(Form::MaxLength, null, 150);

        $form->addText('phone', 'Phone')
            ->setRequired()
            ->addRule(Form::MaxLength, null, 150);

        $form->addText('street', 'Street')
            ->setRequired()
            ->addRule(Form::MaxLength, null, 150);

        $form->addText('city', 'City')
            ->setRequired()
            ->addRule(Form::MaxLength, null, 150);

        $form->addText('psc', 'PSC')
            ->setRequired()
            ->addRule(Form::MaxLength, null, 150);

        $form->addText('country', 'Country')
            ->setRequired()
            ->addRule(Form::MaxLength, null, 150);

        $form->addSubmit('send', 'Order');

        return $form;
    }
}